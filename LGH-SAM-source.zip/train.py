from models.sam import SamPredictor, sam_model_registry
from models.sam.utils.transforms import ResizeLongestSide
from skimage.measure import label
from models.sam_LoRa import LoRA_Sam
import numpy as np
import os
import torch
from torch import nn
import torch.optim as optim
import torchvision
from torchvision import datasets
from torchvision.transforms import InterpolationMode
from tensorboardX import SummaryWriter
import matplotlib.pyplot as plt
from torchvision import transforms
from PIL import Image
from torch.utils.data import DataLoader, Subset
from torch.autograd import Variable
import copy
from utils.dataset import Public_dataset
import torch.nn.functional as F
from torch.nn.functional import one_hot
from pathlib import Path
from tqdm import tqdm
from utils.losses import DiceLoss
from utils.dsc import dice_coeff_multi_class
from utils.medical_metrics import accuracy_score, hausdorff_distance_95
import cv2
import monai
from utils.utils import vis_image
import cfg
import json

# Use the arguments
args = cfg.parse_args()
args.encoder_adapter_depths = list(range(12))

def hsam_forward(sam, imgs, msks, train_mode):
    """H-SAM two-stage hierarchical decoding with ablation switches."""
    img_emb = sam.image_encoder(imgs)
    
    sparse_emb, dense_emb = sam.prompt_encoder(
        points=None, boxes=None, masks=None,
    )
    
    pred1, _, msk_feat, up_embed = sam.mask_decoder(
        image_embeddings=img_emb,
        image_pe=sam.prompt_encoder.get_dense_pe(),
        sparse_prompt_embeddings=sparse_emb,
        dense_prompt_embeddings=dense_emb,
        multimask_output=True,
        return_extras=True,
    )
    
    if getattr(args, 'abl_peft_only', False):
        return pred1, pred1
        
    emb_res = img_emb.shape[-2]
    ps_mask = F.interpolate(pred1, size=(emb_res, emb_res), mode='bilinear', align_corners=False)
    
    # 🔥 核心修复：从 args 获取当前需要的 mode
    current_mode = getattr(args, 'mask_attn_mode', 'learnable')
    if getattr(args, 'abl_no_lmcam', False):
        current_mode = 'none'
    sam.mask_decoder2.mask_attn_mode = current_mode
        
    if getattr(args, 'abl_no_hpd', False):
        up_embed_use = torch.zeros_like(up_embed)
    else:
        up_embed_use = up_embed

    pred2 = sam.mask_decoder2(
        image_embeddings=img_emb,
        image_pe=sam.prompt_encoder.get_dense_pe(),
        sparse_prompt_embeddings=sparse_emb,
        dense_prompt_embeddings=dense_emb,
        mask_feat=ps_mask,
        msk_feat=msk_feat, 
        up_embed=up_embed_use,
        gt=msks if train_mode else None, # 测试时坚决不给 gt
        mode='train' if train_mode else 'test',
    )
    return pred1, pred2

def hsam_average_prob(sam, imgs, msks):
    pred1, pred2 = hsam_forward(sam, imgs, msks, train_mode=False)
    full_res = (args.image_size, args.image_size)
    
    p1 = torch.softmax(F.interpolate(pred1, size=full_res, mode='bilinear', align_corners=False), dim=1)
    
    if getattr(args, 'abl_peft_only', False):
        return p1
        
    p2 = torch.softmax(F.interpolate(pred2, size=full_res, mode='bilinear', align_corners=False), dim=1)
    prob = 0.5 * p1 + 0.5 * p2
    return prob

def train_model(trainloader, valloader, dir_checkpoint, epochs):
    if args.if_warmup:
        b_lr = args.lr / args.warmup_period
    else:
        b_lr = args.lr
    
    sam = sam_model_registry[args.arch](args, checkpoint=os.path.join(args.sam_ckpt), num_classes=args.num_cls)
    
    if args.finetune_type == 'adapter':
        for n, value in sam.named_parameters():
            if "mask_decoder" in n and ("mask_tokens" in n or "output_hypernetworks_mlps" in n or "iou_prediction_head" in n):
                value.requires_grad = True
            elif "Adapter" not in n and "cnn_embed" not in n and "mask_decoder2" not in n:
                value.requires_grad = False
        print('if update encoder:', args.if_update_encoder)
        print('if image encoder adapter:', args.if_encoder_adapter)
        print('if mask decoder adapter:', args.if_mask_decoder_adapter)
        if args.if_encoder_adapter:
            print('added adapter layers:', args.encoder_adapter_depths)
        
    elif args.finetune_type == 'vanilla' and args.if_update_encoder == False:   
        print('if update encoder:', args.if_update_encoder)
        for n, value in sam.image_encoder.named_parameters():
            value.requires_grad = False
    elif args.finetune_type == 'lora':
        print('if update encoder:', args.if_update_encoder)
        print('if image encoder lora:', args.if_encoder_lora_layer)
        print('if mask decoder lora:', args.if_decoder_lora_layer)
        sam = LoRA_Sam(args, sam, r=16).sam
    
    sam.to('cuda')
        
    optimizer = optim.AdamW(sam.parameters(), lr=b_lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.1, amsgrad=False)
    optimizer.zero_grad()
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)
    
    if args.num_cls == 2:
        criterion1 = monai.losses.DiceLoss(sigmoid=True, squared_pred=True, to_onehot_y=True, reduction='mean')
    else:
        criterion1 = monai.losses.DiceLoss(softmax=True, squared_pred=True, to_onehot_y=True, reduction='mean')
        
    # 极其温和的类权重
    if args.num_cls == 9:
        class_weights = torch.tensor([0.5, 1.0, 1.5, 1.2, 1.2, 1.0, 1.5, 1.0, 1.5]).cuda()
        criterion2 = nn.CrossEntropyLoss(weight=class_weights)
    else:
        criterion2 = nn.CrossEntropyLoss()
    
    iter_num = 0
    max_iterations = epochs * len(trainloader) 
    writer = SummaryWriter(dir_checkpoint + '/log')
    
    pbar = tqdm(range(epochs))
    val_largest_dsc = 0
    last_update_epoch = 0
    
    for epoch in pbar:
        sam.train()
        train_loss = 0
        for i, data in enumerate(tqdm(trainloader)):
            imgs = data['image'].cuda()
            
            msks = torchvision.transforms.Resize((args.out_size, args.out_size), interpolation=InterpolationMode.NEAREST)(data['mask']).cuda()
            msks_full = torchvision.transforms.Resize((args.image_size, args.image_size), interpolation=InterpolationMode.NEAREST)(data['mask']).cuda()
            
            pred1, pred2 = hsam_forward(sam, imgs, msks, train_mode=True)
            
            msks_1 = F.interpolate(msks.float(), size=pred1.shape[-2:], mode='nearest').long()
            if msks_1.dim() == 3: msks_1 = msks_1.unsqueeze(1)
            loss1 = criterion1(pred1, msks_1.float()) + criterion2(pred1, torch.squeeze(msks_1, 1))
            
            if getattr(args, 'abl_peft_only', False):
                loss2 = loss1 
            else:
                msks_2 = F.interpolate(msks_full.float(), size=pred2.shape[-2:], mode='nearest').long()
                if msks_2.dim() == 3: msks_2 = msks_2.unsqueeze(1)
                loss2 = criterion1(pred2, msks_2.float()) + criterion2(pred2, torch.squeeze(msks_2, 1))
            
            weight = 0.6 ** (0.990 ** epoch)
            loss = (1 - weight) * loss1 + weight * loss2
            loss_ce, loss_dice = loss1.detach(), loss2.detach()

            loss.backward()
            torch.nn.utils.clip_grad_norm_(sam.parameters(), max_norm=1.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)

            if args.if_warmup and iter_num < args.warmup_period:
                lr_ = args.lr * ((iter_num + 1) / args.warmup_period)
                for param_group in optimizer.param_groups:
                    param_group['lr'] = lr_
            else:
                if args.if_warmup:
                    shift_iter = iter_num - args.warmup_period
                    assert shift_iter >= 0, f'Shift iter is {shift_iter}, smaller than zero'
                    lr_ = args.lr * (1.0 - shift_iter / max_iterations) ** 0.9
                    for param_group in optimizer.param_groups:
                        param_group['lr'] = lr_
                else:
                    lr_ = args.lr

            train_loss += loss.item()
            iter_num += 1
            writer.add_scalar('info/lr', lr_, iter_num)
            writer.add_scalar('info/total_loss', loss, iter_num)
            writer.add_scalar('info/loss_ce', loss_ce, iter_num)
            writer.add_scalar('info/loss_dice', loss_dice, iter_num)

        train_loss /= (i + 1)
        pbar.set_description('Epoch num {}| train loss {} \n'.format(epoch, train_loss))

        if epoch % 2 == 0:
            eval_loss = 0
            eval_acc = eval_f1 = eval_hd95 = 0.0
            n_imgs = 0
            sam.eval()
            
            total_intersection = torch.zeros(args.num_cls, dtype=torch.float64)
            total_gt = torch.zeros(args.num_cls, dtype=torch.float64)
            total_pred = torch.zeros(args.num_cls, dtype=torch.float64)
            
            with torch.no_grad():
                for i, data in enumerate(tqdm(valloader)):
                    imgs = data['image'].cuda()
                    msks = torchvision.transforms.Resize((args.out_size, args.out_size), interpolation=InterpolationMode.NEAREST)(data['mask']).cuda()

                    prob = hsam_average_prob(sam, imgs, msks)
                    prob256 = F.interpolate(prob, size=(args.out_size, args.out_size), mode='bilinear', align_corners=False)
                    pred_lab = prob256.argmax(dim=1).cpu().long()
                    pred_res = prob.argmax(dim=1).cpu().long()
                    
                    loss = criterion1(prob256, msks.float()) + criterion2(prob256, torch.squeeze(msks.long(), 1))
                    eval_loss += loss.item()
                    
                    y = torch.squeeze(msks.long(), 1).cpu().long()
                    p = pred_lab
                    
                    for j in range(1, args.num_cls):  # 只算前景
                        y_bi = (y == j)
                        p_bi = (p == j)
                        I = (y_bi & p_bi).sum().item()
                        total_intersection[j] += I
                        total_gt[j] += y_bi.sum().item()
                        total_pred[j] += p_bi.sum().item()

                    for b in range(pred_lab.shape[0]):
                        orig_msk = np.array(Image.open(os.path.join(args.mask_folder, data['mask_name'][b])).convert('L'), dtype=int) > 0
                        pred_up = F.interpolate(pred_res[b][None, None].float(), size=orig_msk.shape, mode='nearest')[0, 0].numpy().astype(bool)
                        eval_acc += accuracy_score(pred_up, orig_msk)
                        eval_hd95 += hausdorff_distance_95(pred_up, orig_msk)
                    n_imgs += pred_lab.shape[0]

                eval_loss /= (i + 1)
                eval_acc /= n_imgs
                eval_hd95 /= n_imgs

                dsc = 0.0
                valid_classes = 0
                for j in range(1, args.num_cls):
                    gt_sum = total_gt[j].item()
                    pred_sum = total_pred[j].item()
                    if gt_sum == 0:
                        continue
                    I = total_intersection[j].item()
                    dsc += (2.0 * I) / (gt_sum + pred_sum + 1e-8)
                    valid_classes += 1
                dsc = dsc / valid_classes if valid_classes > 0 else 0.0

                writer.add_scalar('eval/loss', eval_loss, epoch)
                writer.add_scalar('eval/dice', dsc, epoch)
                writer.add_scalar('eval/acc', eval_acc, epoch)
                writer.add_scalar('eval/hd95', eval_hd95, epoch)

                print('Eval Epoch num {} | val loss {} | dsc {} | acc {} | hd95 {} \n'.format(epoch, eval_loss, dsc, eval_acc, eval_hd95))
                
                if dsc > val_largest_dsc:
                    val_largest_dsc = dsc
                    last_update_epoch = epoch
                    print('largest foreground DSC now: {}'.format(dsc))
                    torch.save(sam.state_dict(), dir_checkpoint + '/checkpoint_best.pth')
                elif (epoch - last_update_epoch) > 60: 
                    print('Training finished###########')
                    break
    writer.close()

if __name__ == "__main__":
    dataset_name = args.dataset_name
    print('train dataset: {}'.format(dataset_name)) 
    train_img_list = args.train_img_list
    val_img_list = args.val_img_list
    
    num_workers = 8
    if_vis = True
    Path(args.dir_checkpoint).mkdir(parents=True, exist_ok=True)
    path_to_json = os.path.join(args.dir_checkpoint, "args.json")
    args_dict = vars(args)
    with open(path_to_json, 'w') as json_file:
        json.dump(args_dict, json_file, indent=4)
    print(args.targets)

    train_dataset = Public_dataset(args, args.img_folder, args.mask_folder, train_img_list, phase='train', targets=[args.targets], normalize_type='sam', if_prompt=False)
    eval_dataset = Public_dataset(args, args.img_folder, args.mask_folder, val_img_list, phase='val', targets=[args.targets], normalize_type='sam', if_prompt=False)
    
    trainloader = DataLoader(train_dataset, batch_size=args.b, shuffle=True, num_workers=num_workers)
    valloader = DataLoader(eval_dataset, batch_size=args.b, shuffle=False, num_workers=num_workers)

    train_model(trainloader, valloader, args.dir_checkpoint, args.epochs)