from models.sam import SamPredictor, sam_model_registry
import numpy as np
import os
import torch
import torchvision
from torchvision.transforms import InterpolationMode
from PIL import Image
from torch.utils.data import DataLoader
from tqdm import tqdm
import torch.nn.functional as F
from utils.dataset import Public_dataset
from utils.medical_metrics import accuracy_score, hausdorff_distance_95
import cfg
from pathlib import Path
import json
import argparse
from argparse import Namespace

def main(args, test_image_list):
    # 🔥 核心修复：自动读取 checkpoint 文件夹里的 args.json，完美还原模型结构
    args_path = os.path.join(args.dir_checkpoint, 'args.json')
    if os.path.exists(args_path):
        with open(args_path, 'r') as f:
            saved_args = json.load(f)
        # 覆盖当前传入的模型结构参数
        args.encoder_adapter_depths = saved_args.get('encoder_adapter_depths', list(range(12)))
        args.if_encoder_adapter = saved_args.get('if_encoder_adapter', True)
        args.if_mask_decoder_adapter = saved_args.get('if_mask_decoder_adapter', True)
        args.decoder_adapt_depth = saved_args.get('decoder_adapt_depth', 4)
        args.mask_attn_mode = saved_args.get('mask_attn_mode', 'learnable')
        args.image_size = saved_args.get('image_size', args.image_size)
        args.out_size = saved_args.get('out_size', args.out_size)
        print(f"📦 已自动读取模型结构参数: Adapter_Depth={args.decoder_adapt_depth}, Attn_Mode={args.mask_attn_mode}")

    test_dataset = Public_dataset(args, args.img_folder, args.mask_folder, test_image_list, phase='val', targets=[args.targets], if_prompt=False)
    testloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=1)
    
    # 建骨架
    sam_fine_tune = sam_model_registry[args.arch](args, checkpoint=os.path.join(args.sam_ckpt), num_classes=args.num_cls)
    sam_fine_tune.mask_decoder2.mask_attn_mode = args.mask_attn_mode
    
    # 严格加载权重
    checkpoint_path = os.path.join(args.dir_checkpoint, 'checkpoint_best.pth')
    state_dict = torch.load(checkpoint_path, map_location='cuda:0')
    sam_fine_tune.load_state_dict(state_dict, strict=True)
    print("✅ 权重完整加载成功！没有遗漏任何 Adapter！")
    
    sam_fine_tune = sam_fine_tune.to('cuda').eval()
    
    total_intersection = torch.zeros(args.num_cls, dtype=torch.float64)
    total_gt = torch.zeros(args.num_cls, dtype=torch.float64)
    total_pred = torch.zeros(args.num_cls, dtype=torch.float64)
    per_image_results = []

    for i, data in enumerate(tqdm(testloader)):
        imgs = data['image'].to('cuda')
        msks = torchvision.transforms.Resize((args.out_size, args.out_size), interpolation=InterpolationMode.NEAREST)(data['mask']).to('cuda')

        with torch.no_grad():
            scales = [1.0] 
            final_prob = 0
            for scale in scales:
                scaled_size = int(args.image_size * scale)
                scaled_size = max(16, (scaled_size // 16) * 16)
                imgs_scaled = F.interpolate(imgs, size=(scaled_size, scaled_size), mode='bilinear', align_corners=False)
                
                img_emb = sam_fine_tune.image_encoder(imgs_scaled)
                sparse_emb, dense_emb = sam_fine_tune.prompt_encoder(points=None, boxes=None, masks=None)
                
                pred1, _, msk_feat, up_embed = sam_fine_tune.mask_decoder(
                    image_embeddings=img_emb, image_pe=sam_fine_tune.prompt_encoder.get_dense_pe(),
                    sparse_prompt_embeddings=sparse_emb, dense_prompt_embeddings=dense_emb,
                    multimask_output=True, return_extras=True,
                )
                emb_res = img_emb.shape[-2]
                ps_mask = F.interpolate(pred1, size=(emb_res, emb_res), mode='bilinear', align_corners=False)
                
                pred2 = sam_fine_tune.mask_decoder2(
                    image_embeddings=img_emb, image_pe=sam_fine_tune.prompt_encoder.get_dense_pe(),
                    sparse_prompt_embeddings=sparse_emb, dense_prompt_embeddings=dense_emb,
                    mask_feat=ps_mask, msk_feat=msk_feat, up_embed=up_embed, gt=None, mode='test',
                )
                
                prob1 = torch.softmax(F.interpolate(pred1, size=(scaled_size, scaled_size), mode='bilinear', align_corners=False), dim=1)
                prob2 = torch.softmax(pred2, dim=1)
                prob = 0.5 * prob1 + 0.5 * prob2
                prob_out = F.interpolate(prob, size=(args.out_size, args.out_size), mode='bilinear', align_corners=False)
                final_prob += prob_out
                
            final_prob = final_prob / len(scales)
            pred_fine = final_prob.argmax(dim=1)

        yhat = pred_fine.cpu().long().flatten()
        y = msks.cpu().flatten()

        for j in range(1, args.num_cls):
            y_bi = (y == j)
            yhat_bi = (yhat == j)
            I = (y_bi & yhat_bi).sum().item()
            total_intersection[j] += I
            total_gt[j] += y_bi.sum().item()
            total_pred[j] += yhat_bi.sum().item()

        orig_msk = np.array(Image.open(os.path.join(args.mask_folder, data['mask_name'][0])).convert('L'), dtype=int) > 0
        pred_res = pred_fine[0].unsqueeze(0).unsqueeze(0).float()
        pred_up = F.interpolate(pred_res, size=orig_msk.shape, mode='nearest')[0, 0].cpu().numpy().astype(bool)
        
        img_acc = accuracy_score(pred_up, orig_msk)
        img_hd95 = hausdorff_distance_95(pred_up, orig_msk)
        per_image_results.append({'img_name': data['img_name'][0], 'acc': img_acc, 'hd95': img_hd95})

    dsc_per_cls = []
    iou_per_cls = []
    class_dsc_tensor = torch.zeros(args.num_cls)
    class_iou_tensor = torch.zeros(args.num_cls)
    
    for j in range(1, args.num_cls):
        gt_sum = total_gt[j].item()
        pred_sum = total_pred[j].item()
        if gt_sum == 0: continue
        I = total_intersection[j].item()
        dsc = (2.0 * I) / (gt_sum + pred_sum + 1e-8)
        iou = I / (gt_sum + pred_sum - I + 1e-8)
        dsc_per_cls.append(dsc)
        iou_per_cls.append(iou)
        class_dsc_tensor[j] = dsc
        class_iou_tensor[j] = iou

    acc  = np.mean([m['acc'] for m in per_image_results]) * 100
    hd95 = np.mean([m['hd95'] for m in per_image_results])
    f1   = float(np.mean(dsc_per_cls)) * 100 if len(dsc_per_cls) > 0 else 0.0
    miou = float(np.mean(iou_per_cls)) * 100 if len(iou_per_cls) > 0 else 0.0

    save_folder = os.path.join('test_results', args.dir_checkpoint)
    Path(save_folder).mkdir(parents=True, exist_ok=True)

    print(f"\nDataset: {args.dataset_name}")
    print('class dsc:', class_dsc_tensor)
    print('class iou:', class_iou_tensor)
    print('\n============================ Evaluation metrics (Foreground) ============================') 
    print('{:<50s} {:>10s} {:>8s} {:>10s} {:>8s}'.format('Method', 'ACC(%)', 'F1(%)', 'mIoU(%)', 'HD95'))
    print('{:<50s} {:>10.2f} {:>8.2f} {:>10.2f} {:>8.2f}'.format('MedAdapt-SAM', acc, f1, miou, hd95))

    results = {'mean': {'ACC_%': acc, 'F1_%': f1, 'mIoU_%': miou, 'HD95_px': hd95}, 'per_image': per_image_results}
    with open(os.path.join(save_folder, 'medical_metrics.json'), 'w') as f:
        json.dump(results, f, indent=4)
    print(f'\nResults saved to {os.path.join(save_folder, "medical_metrics.json")}')

if __name__ == "__main__":
    args = cfg.parse_args()
    main(args, args.val_img_list)