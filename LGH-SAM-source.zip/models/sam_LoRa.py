from .sam import build_sam, SamPredictor
from .sam import sam_model_registry

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn.parameter import Parameter
# Optional imports; only needed for the LoRA fine-tuning path
try:
    from segment_anything.modeling import Sam
    from safetensors import safe_open
    from safetensors.torch import save_file
    from icecream import ic
except ImportError:
    Sam = None
    safe_open = save_file = None
    def ic(*a, **k): pass


class _LoRA_qkv(nn.Module):
    def __init__(
            self,
            qkv: nn.Module,
            linear_a_q: nn.Module,
            linear_b_q: nn.Module,
            linear_a_v: nn.Module,
            linear_b_v: nn.Module,
    ):
        super().__init__()
        self.qkv = qkv
        self.linear_a_q = linear_a_q
        self.linear_b_q = linear_b_q
        self.linear_a_v = linear_a_v
        self.linear_b_v = linear_b_v
        self.dim = qkv.in_features
        self.w_identity = torch.eye(qkv.in_features)

    def forward(self, x):
        qkv = self.qkv(x)  # B,N,N,3*org_C
        new_q = self.linear_b_q(self.linear_a_q(x))
        new_v = self.linear_b_v(self.linear_a_v(x))
        try:
            qkv[:, :, :, : self.dim] += new_q
            qkv[:, :, :, -self.dim:] += new_v
        except:
            qkv[:, :, :self.dim] += new_q
            qkv[:, :, -self.dim:] += new_v 
        return qkv


class _LoRA_qkv_proj(nn.Module):
    def __init__(self, proj: nn.Module, w_a: nn.Module, w_b: nn.Module):
        super().__init__()
        self.proj = proj
        self.w_a = w_a
        self.w_b = w_b

    def forward(self, x):
        x = self.proj(x) + self.w_b(self.w_a(x))
        return x
    
class LoRA_Sam(nn.Module):
    def __init__(self, args, sam_model: Sam, r: int):
        super(LoRA_Sam, self).__init__()

        assert r > 0
        self.args = args
        
        if self.args.if_encoder_lora_layer:
            if len(self.args.encoder_lora_layer)>0:
                self.lora_layer = self.args.encoder_lora_layer
            else:
                self.lora_layer = list(
                    range(len(sam_model.image_encoder.blocks)))

            self.w_As = []
            self.w_Bs = []

            for param in sam_model.image_encoder.parameters():
                param.requires_grad = False

            try:
                for t_layer_i, blk in enumerate(sam_model.image_encoder.blocks):
                    if t_layer_i not in self.lora_layer:
                        continue
                    w_qkv_linear = blk.attn.qkv
                    self.dim = w_qkv_linear.in_features
                    w_a_linear_q = nn.Linear(self.dim, r, bias=False)
                    w_b_linear_q = nn.Linear(r, self.dim, bias=False)

                    w_a_linear_v = nn.Linear(self.dim, r, bias=False)
                    w_b_linear_v = nn.Linear(r, self.dim, bias=False)

                    self.w_As.append(w_a_linear_q)
                    self.w_Bs.append(w_b_linear_q)
                    self.w_As.append(w_a_linear_v)
                    self.w_Bs.append(w_b_linear_v)

                    blk.attn.qkv = _LoRA_qkv(
                        w_qkv_linear,
                        w_a_linear_q,
                        w_b_linear_q,
                        w_a_linear_v,
                        w_b_linear_v,
                    )
            except:
                for n, value in sam_model.image_encoder.layers[0].named_parameters():
                    value.requires_grad = True
                for t_layer_i, layer in enumerate(sam_model.image_encoder.layers[1:]):
                    if t_layer_i not in self.lora_layer:
                        continue
                    for b_i, blk in enumerate(layer.blocks):
                        w_qkv_linear = blk.attn.qkv
                        self.dim = w_qkv_linear.in_features
                        w_a_linear_q = nn.Linear(self.dim, r, bias=False)
                        w_b_linear_q = nn.Linear(r, self.dim, bias=False)

                        w_a_linear_v = nn.Linear(self.dim, r, bias=False)
                        w_b_linear_v = nn.Linear(r, self.dim, bias=False)

                        self.w_As.append(w_a_linear_q)
                        self.w_Bs.append(w_b_linear_q)
                        self.w_As.append(w_a_linear_v)
                        self.w_Bs.append(w_b_linear_v)

                        blk.attn.qkv = _LoRA_qkv(
                            w_qkv_linear,
                            w_a_linear_q,
                            w_b_linear_q,
                            w_a_linear_v,
                            w_b_linear_v,
                        )

        if self.args.if_decoder_lora_layer:
            self.self_attn_As = []
            self.self_attn_Bs = []
            self.cross_attn_ti_As = []
            self.cross_attn_ti_Bs = []
            self.cross_attn_it_As = []
            self.cross_attn_it_Bs = []
            for param in sam_model.mask_decoder.transformer.parameters():
                param.requires_grad = False
            decoder_transformer = sam_model.mask_decoder.transformer
            for layer_idx, blk in enumerate(decoder_transformer.layers):
                self_attn_q_proj = blk.self_attn.q_proj
                self_attn_v_proj = blk.self_attn.v_proj
                input_dim = blk.self_attn.embedding_dim
                output_dim = blk.self_attn.internal_dim
                w_a_linear_q_self_attn = nn.Linear(input_dim, r, bias=False)
                w_b_linear_q_self_attn = nn.Linear(r, output_dim, bias=False)
                w_a_linear_v_self_attn = nn.Linear(input_dim, r, bias=False)
                w_b_linear_v_self_attn = nn.Linear(r, output_dim, bias=False)
                self.self_attn_As.append(w_a_linear_q_self_attn)
                self.self_attn_Bs.append(w_b_linear_q_self_attn)
                self.self_attn_As.append(w_a_linear_v_self_attn)
                self.self_attn_Bs.append(w_b_linear_v_self_attn)
                blk.self_attn.q_proj = _LoRA_qkv_proj(self_attn_q_proj, w_a_linear_q_self_attn, w_b_linear_q_self_attn)
                blk.self_attn.v_proj = _LoRA_qkv_proj(self_attn_v_proj, w_a_linear_v_self_attn, w_b_linear_v_self_attn)

                cross_attn_ti_q_proj = blk.cross_attn_token_to_image.q_proj
                cross_attn_ti_v_proj = blk.cross_attn_token_to_image.v_proj
                ti_input_dim = blk.cross_attn_token_to_image.embedding_dim
                ti_output_dim = blk.cross_attn_token_to_image.internal_dim
                w_a_linear_q_cross_attn_ti = nn.Linear(ti_input_dim, r, bias=False)
                w_b_linear_q_cross_attn_ti = nn.Linear(r, ti_output_dim, bias=False)
                w_a_linear_v_cross_attn_ti = nn.Linear(ti_input_dim, r, bias=False)
                w_b_linear_v_cross_attn_ti = nn.Linear(r, ti_output_dim, bias=False)
                self.cross_attn_ti_As.append(w_a_linear_q_cross_attn_ti)
                self.cross_attn_ti_Bs.append(w_b_linear_q_cross_attn_ti)
                self.cross_attn_ti_As.append(w_a_linear_v_cross_attn_ti)
                self.cross_attn_ti_Bs.append(w_b_linear_v_cross_attn_ti)
                blk.cross_attn_token_to_image.q_proj = _LoRA_qkv_proj(cross_attn_ti_q_proj, w_a_linear_q_cross_attn_ti, w_b_linear_q_cross_attn_ti)
                blk.cross_attn_token_to_image.v_proj = _LoRA_qkv_proj(cross_attn_ti_v_proj, w_a_linear_v_cross_attn_ti, w_b_linear_v_cross_attn_ti)

                cross_attn_it_q_proj = blk.cross_attn_image_to_token.q_proj
                cross_attn_it_v_proj = blk.cross_attn_image_to_token.v_proj
                it_input_dim = blk.cross_attn_image_to_token.embedding_dim
                it_output_dim = blk.cross_attn_image_to_token.internal_dim
                w_a_linear_q_cross_attn_it = nn.Linear(it_input_dim, r, bias=False)
                w_b_linear_q_cross_attn_it = nn.Linear(r, it_output_dim, bias=False)
                w_a_linear_v_cross_attn_it = nn.Linear(it_input_dim, r, bias=False)
                w_b_linear_v_cross_attn_it = nn.Linear(r, it_output_dim, bias=False)
                self.cross_attn_it_As.append(w_a_linear_q_cross_attn_it)
                self.cross_attn_it_Bs.append(w_b_linear_q_cross_attn_it)
                self.cross_attn_it_As.append(w_a_linear_v_cross_attn_it)
                self.cross_attn_it_Bs.append(w_b_linear_v_cross_attn_it)
                blk.cross_attn_image_to_token.q_proj = _LoRA_qkv_proj(cross_attn_it_q_proj, w_a_linear_q_cross_attn_it, w_b_linear_q_cross_attn_it)
                blk.cross_attn_image_to_token.v_proj = _LoRA_qkv_proj(cross_attn_it_v_proj, w_a_linear_v_cross_attn_it, w_b_linear_v_cross_attn_it)

            block = decoder_transformer.final_attn_token_to_image
            fa_ti_q_proj = block.q_proj
            fa_ti_v_proj = block.v_proj
            in_dim, out_dim = block.embedding_dim, block.internal_dim
            self.fa_ti_q_proj_A = nn.Linear(in_dim, r, bias=False)
            self.fa_ti_q_proj_B = nn.Linear(r, out_dim, bias=False)
            self.fa_ti_v_proj_A = nn.Linear(in_dim, r, bias=False)
            self.fa_ti_v_proj_B = nn.Linear(r, out_dim, bias=False)
            block.q_proj = _LoRA_qkv_proj(fa_ti_q_proj, self.fa_ti_q_proj_A, self.fa_ti_q_proj_B)
            block.v_proj = _LoRA_qkv_proj(fa_ti_v_proj, self.fa_ti_v_proj_A, self.fa_ti_v_proj_B)

        self.reset_parameters()
        
        # =========================================================
        # 【核心修复】强制解冻 MedAdapt-SAM 特有的模块和重新初始化的预测头
        # 让 LoRA 和 Adapter 在相同的起跑线上！
        # =========================================================
        for name, param in sam_model.named_parameters():
            # 1. 解冻预测头（因为你改了 num_classes）
            if "mask_decoder" in name and ("mask_tokens" in name or "output_hypernetworks_mlps" in name or "iou_prediction_head" in name):
                param.requires_grad = True
            # 2. 解冻 H-SAM 的特有分支
            if any(keyword in name for keyword in ["Adapter", "cnn_embed", "mask_decoder2"]):
                param.requires_grad = True
                
        self.sam = sam_model
        
    def reset_parameters(self) -> None:
        if self.args.if_encoder_lora_layer:
            for w_A in self.w_As:
                nn.init.kaiming_uniform_(w_A.weight, a=math.sqrt(5))
            for w_B in self.w_Bs:
                nn.init.zeros_(w_B.weight)
        if self.args.if_decoder_lora_layer:
            for w_A in self.self_attn_As:
                nn.init.kaiming_uniform_(w_A.weight, a=math.sqrt(5))
            for w_B in self.self_attn_Bs:
                nn.init.zeros_(w_B.weight)
            for w_A in self.cross_attn_ti_As:
                nn.init.kaiming_uniform_(w_A.weight, a=math.sqrt(5))
            for w_B in self.cross_attn_ti_Bs:
                nn.init.zeros_(w_B.weight)
            for w_A in self.cross_attn_it_As:
                nn.init.kaiming_uniform_(w_A.weight, a=math.sqrt(5))
            for w_B in self.cross_attn_it_Bs:
                nn.init.zeros_(w_B.weight)
            nn.init.kaiming_uniform_(self.fa_ti_q_proj_A.weight, a=math.sqrt(5))
            nn.init.zeros_(self.fa_ti_q_proj_B.weight)
            nn.init.kaiming_uniform_(self.fa_ti_v_proj_A.weight, a=math.sqrt(5))
            nn.init.zeros_(self.fa_ti_v_proj_B.weight)
        
    def forward(self, batched_input, multimask_output,image_size):
        return self.sam(batched_input, multimask_output,image_size)