# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import math

import torch
import torch.utils.checkpoint
from torch import nn, Tensor
from torch.nn import functional as F

from typing import List, Tuple, Type

from .common import LayerNorm2d, Adapter
from .vit import TransformerEncoder
from einops import rearrange


class SmallDecoder(nn.Module):
    def __init__(
        self,
        input_chans = 256,
        prompt_embed_dim=256,
        img_size = (256,256),
        patch_size = 1,
        scale = 256 ** -0.5,
        activation = nn.GELU,
        depth = 1,
        n_cls=1)-> None:
        super().__init__()
        self.scale = scale
        self.n_cls = n_cls
        self.img_size = img_size
        self.patch_size = patch_size
        
        self.cls_emb = nn.Parameter(
            torch.randn([1, n_cls, prompt_embed_dim]))
        self.dec_proj = nn.Linear(prompt_embed_dim, prompt_embed_dim)
        
        self.decoder_norm = nn.LayerNorm(prompt_embed_dim)
        self.mask_norm = nn.LayerNorm(n_cls)
        
        self.proj_patch = nn.Parameter(
            self.scale * torch.randn(prompt_embed_dim, prompt_embed_dim))
        self.proj_classes = nn.Parameter(
            self.scale * torch.randn(prompt_embed_dim, prompt_embed_dim))
        
        self.blocks = TransformerEncoder(depth=depth)
        
        self.upsampling = nn.Sequential(
            nn.ConvTranspose2d(prompt_embed_dim, prompt_embed_dim, kernel_size=2, stride=2),
            LayerNorm2d(prompt_embed_dim),
            activation(),
            nn.ConvTranspose2d(prompt_embed_dim, prompt_embed_dim, kernel_size=2, stride=2),
            activation(),
        )
        
    def forward(self,
        image_embedding: torch.Tensor)-> torch.Tensor:
        b, c, h, w = image_embedding.shape
        #x = self.input(image_embedding) # b*in_chan*h*w -> b*1*h*w
        image_embedding = image_embedding.flatten(2).permute(0, 2, 1)
        #print('in shape:',image_embedding.shape) # b*(h*w)*emb_dim
    
        H, W = self.img_size
        GS = H//self.patch_size
        x = self.dec_proj(image_embedding)
        
        # Adding a cls token for each segmenting class
        cls_emb = self.cls_emb.expand(x.size(0), -1, -1)
        x = torch.cat((x, cls_emb), 1)
        #print('x shape:',x.shape)
        out = (self.blocks(x)) # one transformer block
        #print('out shape:',out.shape)
        
        x = self.decoder_norm(out)

        patches, cls_seg_feat = x[:, :-self.n_cls], x[:, -self.n_cls:]
        
        # new added up-sampling        
        patches = patches.transpose(1,2).view(b, c, h, w) # b * 256 * 64* 64
        patches = self.upsampling(patches) # b * 256 * 256 * 256
        patches = patches.flatten(2).permute(0, 2, 1) # b * 256^2 * 256
        
        
        patches = patches @ self.proj_patch # b * 256^2 * 256
        cls_seg_feat = cls_seg_feat @ self.proj_classes # b * 1 * 256
        
        
        patches = patches / patches.norm(dim=-1, keepdim=True) # b * 256^2 * 256
        #print('patches shape:',patches.shape)
        cls_seg_feat = cls_seg_feat / cls_seg_feat.norm(dim=-1, keepdim=True)  # b * 1 * 256
        #print('cls_seg shape:',cls_seg_feat.shape)
        masks = patches @ cls_seg_feat.transpose(1, 2) 
        
        #masks = self.mask_norm(masks)
        
        #print('after norm:',masks)
        masks = rearrange(masks, "b (h w) n -> b n h w", h=int(GS))
        #print(masks)
        #out = F.interpolate(masks, size=(H, W), mode="bilinear")
        out = masks
        return out
        


class MaskDecoder(nn.Module):
    def __init__(
        self,
        *,
        transformer_dim: int,
        transformer: nn.Module,
        num_multimask_outputs: int = 3,
        activation: Type[nn.Module] = nn.GELU,
        iou_head_depth: int = 3,
        iou_head_hidden_dim: int = 256,
    ) -> None:
        """
        Predicts masks given an image and prompt embeddings, using a
        transformer architecture.

        Arguments:
          transformer_dim (int): the channel dimension of the transformer
          transformer (nn.Module): the transformer used to predict masks
          num_multimask_outputs (int): the number of masks to predict
            when disambiguating masks
          activation (nn.Module): the type of activation to use when
            upscaling masks
          iou_head_depth (int): the depth of the MLP used to predict
            mask quality
          iou_head_hidden_dim (int): the hidden dimension of the MLP
            used to predict mask quality
        """
        super().__init__()
        self.transformer_dim = transformer_dim
        self.transformer = transformer

        self.num_multimask_outputs = num_multimask_outputs

        self.iou_token = nn.Embedding(1, transformer_dim)
        self.num_mask_tokens = num_multimask_outputs + 1
        self.mask_tokens = nn.Embedding(self.num_mask_tokens, transformer_dim)

        self.output_upscaling = nn.Sequential(
            nn.ConvTranspose2d(transformer_dim, transformer_dim // 4, kernel_size=2, stride=2),
            LayerNorm2d(transformer_dim // 4),
            activation(),
            nn.ConvTranspose2d(transformer_dim // 4, transformer_dim // 8, kernel_size=2, stride=2),
            activation(),
        )
        self.output_hypernetworks_mlps = nn.ModuleList(
            [
                MLP(transformer_dim, transformer_dim, transformer_dim // 8, 3)
                for i in range(self.num_mask_tokens)
            ]
        )

        self.iou_prediction_head = MLP(
            transformer_dim, iou_head_hidden_dim, self.num_mask_tokens, iou_head_depth
        )

    def forward(
        self,
        image_embeddings: torch.Tensor,
        image_pe: torch.Tensor,
        sparse_prompt_embeddings: torch.Tensor,
        dense_prompt_embeddings: torch.Tensor,
        multimask_output: bool,
        return_extras: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Predict masks given image and prompt embeddings.
        """
        masks, iou_pred, msk_feat, up_embed = self.predict_masks(
            image_embeddings=image_embeddings,
            image_pe=image_pe,
            sparse_prompt_embeddings=sparse_prompt_embeddings,
            dense_prompt_embeddings=dense_prompt_embeddings,
        )

        # Select the correct mask or masks for output
        if multimask_output:
            mask_slice = slice(1, None)
        else:
            mask_slice = slice(0, 1)
        masks = masks[:, mask_slice, :, :]
        iou_pred = iou_pred[:, mask_slice]

        # Prepare output
        if return_extras:
            return masks, iou_pred, msk_feat, up_embed
        return masks, iou_pred

    def predict_masks(
        self,
        image_embeddings: torch.Tensor,
        image_pe: torch.Tensor,
        sparse_prompt_embeddings: torch.Tensor,
        dense_prompt_embeddings: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Predicts masks. See 'forward' for more details."""
        
        # ================= 修复补丁：动态缩放位置编码 =================
        # 获取目标特征图的 H, W 尺寸 (比如 14x14)
        target_size = image_embeddings.shape[-2:]
        
        # 1. 动态缩放 dense_prompt_embeddings (B, C, H, W)
        if dense_prompt_embeddings.shape[-2:] != target_size:
            dense_prompt_embeddings = F.interpolate(
                dense_prompt_embeddings, 
                size=target_size, 
                mode="bicubic", 
                align_corners=False
            )
            
        # 2. 动态缩放 image_pe (B, C, H, W)
        if image_pe.shape[-2:] != target_size:
            image_pe = F.interpolate(
                image_pe, 
                size=target_size, 
                mode="bicubic", 
                align_corners=False
            )
        # ==============================================================

        # Concatenate output tokens
        output_tokens = torch.cat([self.iou_token.weight, self.mask_tokens.weight], dim=0)
        output_tokens = output_tokens.unsqueeze(0).expand(sparse_prompt_embeddings.size(0), -1, -1)
        tokens = torch.cat((output_tokens, sparse_prompt_embeddings), dim=1)

        # Expand per-image data in batch direction to be per-mask
        if image_embeddings.shape[0] != tokens.shape[0]:
            src = torch.repeat_interleave(image_embeddings, tokens.shape[0], dim=0)
        else:
            src = image_embeddings
            
        # 此时 src 的 shape 是 (B, C, H, W)，dense_prompt_embeddings 也是 (B, C, H, W)
        # 直接相加，不需要 permute！
        src = src + dense_prompt_embeddings
        
        # 处理 pos_src (位置编码)
        pos_src = torch.repeat_interleave(image_pe, tokens.shape[0], dim=0)
        
        b, c, h, w = src.shape

        # Run the transformer
        hs, src = self.transformer(src, pos_src, tokens)
        iou_token_out = hs[:, 0, :]
        mask_tokens_out = hs[:, 1 : (1 + self.num_mask_tokens), :]

        # mask-token logits over the image embeddings, used by the H-SAM CMAttn
        msk_feat = torch.matmul(mask_tokens_out, src.transpose(1, 2))

        # Upscale mask embeddings and predict masks using the mask tokens
        src = src.transpose(1, 2).view(b, c, h, w)
        upscaled_embedding = self.output_upscaling(src)
        hyper_in_list: List[torch.Tensor] = []
        for i in range(self.num_mask_tokens):
            hyper_in_list.append(self.output_hypernetworks_mlps[i](mask_tokens_out[:, i, :]))
        hyper_in = torch.stack(hyper_in_list, dim=1)
        b, c, h, w = upscaled_embedding.shape
        masks = (hyper_in @ upscaled_embedding.view(b, c, h * w)).view(b, -1, h, w)

        # Generate mask quality predictions
        iou_pred = self.iou_prediction_head(iou_token_out)

        return masks, iou_pred, msk_feat, upscaled_embedding

# Lightly adapted from
# https://github.com/facebookresearch/MaskFormer/blob/main/mask_former/modeling/transformer/transformer_predictor.py # noqa
class MLP(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_layers: int,
        sigmoid_output: bool = False,
    ) -> None:
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(
            nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim])
        )
        self.sigmoid_output = sigmoid_output

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        if self.sigmoid_output:
            x = F.sigmoid(x)
        return x


# ---------------------------------------------------------------------------
# H-SAM components (https://github.com/Ccccz404/H-SAM): Class-Balanced
# Mask-Guided Self-Attention (CMAttn), Learnable Mask Cross-Attention (LMCA)
# and the hierarchical pixel decoder, adapted for the prompt-free
# pipeline. The second-stage decoder (MaskDecoder2) consumes the first-stage
# SAM decoder outputs (prior mask, mask-token logits and pixel-decoder
# embedding) and produces full-resolution masks.
# ---------------------------------------------------------------------------

# per-class Gaussian-noise std for the class-balanced augmentation,
# ordered from the rarest to the most frequent class (H-SAM noise_list)
noise_list = [0.35, 0.3, 0.3, 0.2, 0.2, 0.1, 0.1, 0.0, 0.0]


class MLPBlock(nn.Module):
    def __init__(
        self,
        embedding_dim: int,
        mlp_dim: int,
        act: Type[nn.Module] = nn.ReLU,
    ) -> None:
        super().__init__()
        self.lin1 = nn.Linear(embedding_dim, mlp_dim)
        self.lin2 = nn.Linear(mlp_dim, embedding_dim)
        self.act = act()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.lin2(self.act(self.lin1(x)))


class Attention(nn.Module):
    """Standard multi-head attention used inside CMAttn and TwoWayTransformer2."""

    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        downsample_rate: int = 1,
    ) -> None:
        super().__init__()
        self.embedding_dim = embedding_dim
        self.internal_dim = embedding_dim // downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0, "num_heads must divide embedding_dim."

        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)

    def _separate_heads(self, x: Tensor, num_heads: int) -> Tensor:
        b, n, c = x.shape
        x = x.reshape(b, n, num_heads, c // num_heads)
        return x.transpose(1, 2)

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, n_heads, n_tokens, c_per_head = x.shape
        x = x.transpose(1, 2)
        return x.reshape(b, n_tokens, n_heads * c_per_head)

    def forward(self, q: Tensor, k: Tensor, v: Tensor) -> Tensor:
        q = self.q_proj(q)
        k = self.k_proj(k)
        v = self.v_proj(v)

        q = self._separate_heads(q, self.num_heads)
        k = self._separate_heads(k, self.num_heads)
        v = self._separate_heads(v, self.num_heads)

        _, _, _, c_per_head = q.shape
        attn = q @ k.permute(0, 1, 3, 2)
        attn = attn / math.sqrt(c_per_head)
        attn = torch.softmax(attn, dim=-1)

        out = attn @ v
        out = self._recombine_heads(out)
        out = self.out_proj(out)

        return out


class CMAttn(nn.Module):
    """Class-Balanced Mask-Guided Self-Attention: refines the stage-1
    class-token logit maps with self-attention + FFN, applies the
    class-balanced Gaussian augmentation during training, and produces a
    per-position gate used to enhance the image embeddings."""

    def __init__(
        self,
        stage1_num_tokens: int,
        embed_dim: int = 1024,
        num_heads: int = 8,
        mlp_dim: int = 2048,
    ) -> None:
        super().__init__()
        self.embed_dim = embed_dim
        self.feat_size = int(math.sqrt(embed_dim))
        self.med_sel = nn.Sequential(
            nn.Linear(stage1_num_tokens, 1),
            nn.ReLU(),
        )
        self.self_attn = Attention(embed_dim, num_heads=num_heads)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.self_attn2 = Attention(embed_dim, num_heads=num_heads)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = MLPBlock(embed_dim, mlp_dim)

    def forward(
        self,
        msk_feat: torch.Tensor,
        h: int,
        w: int,
        gt: torch.Tensor = None,
        mode: str = 'test',
    ) -> torch.Tensor:
        # 获取输入张量的 batch 和 token 维度
        b, t, hw = msk_feat.shape
        
        # 【核心修复】强制计算出期望的特征图边长 (32)
        side = int(self.embed_dim ** 0.5)
        
        # 【核心修复】如果输入尺寸 (如24x24) 不等于期望尺寸 (32x32)，强行插值
        if hw != self.embed_dim:
            msk_feat = msk_feat.view(b, t, h, w)
            msk_feat = F.interpolate(msk_feat, size=(side, side), mode='bilinear', align_corners=False)
            msk_feat = msk_feat.view(b, t, -1) # 展平成 (B, T, 1024)
        
        if mode == 'train' and gt is not None:
            msk_feat = F.dropout(msk_feat, p=0.1)
            
            # 处理 GT 掩码
            gt_map = gt.float()
            if gt_map.dim() == 4:
                gt_map = gt_map.squeeze(1)
            elif gt_map.dim() == 2:
                gt_map = gt_map.unsqueeze(0)
            
            # 动态匹配到特征图尺寸 (32x32)
            gt_feat = F.interpolate(gt_map.unsqueeze(1), size=(side, side), mode='nearest')
            gt_feat = gt_feat.long().view(b, 1, -1).repeat(1, t, 1)
            
            # 计算噪声
            labs, cnts = torch.unique(gt_feat, sorted=True, return_counts=True)
            order = torch.argsort(cnts)
            noise_mean = msk_feat.mean()
            noise_list = getattr(self, 'noise_list', [0.1, 0.2, 0.3, 0.4, 0.5])
            
            for i, lab_ind in enumerate(order):
                var = noise_list[min(i, len(noise_list) - 1)]
                noise = torch.randn_like(msk_feat) * var + noise_mean
                sel = (gt_feat == labs[lab_ind]).float()
                msk_feat = msk_feat + noise * sel

        # 注意力计算
        msk_feat = self.self_attn(msk_feat, msk_feat, msk_feat)
        msk_feat = self.norm1(msk_feat)
        msk_feat = self.self_attn2(msk_feat, msk_feat, msk_feat)
        msk_feat = msk_feat + self.mlp(msk_feat)
        msk_feat = self.norm2(msk_feat)

        # 聚合
        msk_feat = self.med_sel(msk_feat.transpose(-2, -1))
        msk_feat = msk_feat.transpose(-1, -2).view(b, 1, side, side)
        
        # 还原回原始的 h, w
        if side != h or side != w:
            msk_feat = F.interpolate(msk_feat, size=(h, w), mode='bilinear', align_corners=False)
            
        return msk_feat


class Attention2(nn.Module):
    """SAM attention with Learnable Mask Cross-Attention (LMCA): the softmax
    attention map is element-wise modulated by the prior probabilistic mask."""

    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        downsample_rate: int = 1,
    ) -> None:
        super().__init__()
        self.embedding_dim = embedding_dim
        self.internal_dim = embedding_dim // downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0, "num_heads must divide embedding_dim."

        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)

    def _separate_heads(self, x: Tensor, num_heads: int) -> Tensor:
        b, n, c = x.shape
        x = x.reshape(b, n, num_heads, c // num_heads)
        return x.transpose(1, 2)

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, n_heads, n_tokens, c_per_head = x.shape
        x = x.transpose(1, 2)
        return x.reshape(b, n_tokens, n_heads * c_per_head)

    def forward(self, q: Tensor, k: Tensor, v: Tensor, mask_feat: Tensor = None) -> Tensor:
        q = self.q_proj(q)
        k = self.k_proj(k)
        v = self.v_proj(v)

        q = self._separate_heads(q, self.num_heads)
        k = self._separate_heads(k, self.num_heads)
        v = self._separate_heads(v, self.num_heads)

        _, _, _, c_per_head = q.shape
        attn = q @ k.permute(0, 1, 3, 2)
        attn = attn / math.sqrt(c_per_head)
        attn = torch.softmax(attn, dim=-1)

        if mask_feat is not None:
            mf = mask_feat.unsqueeze(1)
            mf = torch.repeat_interleave(mf, self.num_heads, dim=1)
            if mf.shape[-1] == attn.shape[-1]:
                attn = torch.mul(attn, mf)
            else:
                attn = torch.mul(attn, mf.transpose(2, 3))

        out = attn @ v
        out = self._recombine_heads(out)
        out = self.out_proj(out)

        return out


class TwoWayAttentionBlock2(nn.Module):
    """SAM two-way block with LMCA in both cross-attention layers."""

    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        mlp_dim: int = 2048,
        activation: Type[nn.Module] = nn.ReLU,
        attention_downsample_rate: int = 2,
        skip_first_layer_pe: bool = False,
    ) -> None:
        super().__init__()
        self.self_attn = Attention(embedding_dim, num_heads)
        self.norm1 = nn.LayerNorm(embedding_dim)

        self.cross_attn_token_to_image = Attention2(embedding_dim, num_heads)
        self.norm2 = nn.LayerNorm(embedding_dim)

        self.mlp = MLPBlock(embedding_dim, mlp_dim, activation)
        self.norm3 = nn.LayerNorm(embedding_dim)

        self.norm4 = nn.LayerNorm(embedding_dim)
        self.cross_attn_image_to_token = Attention2(embedding_dim, num_heads)

        self.skip_first_layer_pe = skip_first_layer_pe
        self.dropout = nn.Dropout(0.2)

    def forward(
        self, queries: Tensor, keys: Tensor, query_pe: Tensor, key_pe: Tensor, mask_feat: Tensor
    ) -> Tuple[Tensor, Tensor]:
        # Cross attention block, tokens attending to image embedding
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_token_to_image(q=q, k=k, v=keys, mask_feat=mask_feat)
        queries = queries + self.dropout(attn_out)
        queries = self.norm2(queries)

        # Self attention block
        if self.skip_first_layer_pe:
            queries = self.self_attn(q=queries, k=queries, v=queries)
        else:
            q = queries + query_pe
            attn_out = self.self_attn(q=q, k=q, v=queries)
            queries = queries + attn_out
        queries = self.norm1(queries)

        # MLP block
        mlp_out = self.mlp(queries)
        queries = queries + mlp_out
        queries = self.norm3(queries)

        # Cross attention block, image embedding attending to tokens
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_image_to_token(q=k, k=q, v=queries, mask_feat=mask_feat)
        keys = keys + attn_out
        keys = self.norm4(keys)

        return queries, keys


class TwoWayTransformer2(nn.Module):
    """Second-stage transformer decoder whose cross-attention uses LMCA."""

    def __init__(
        self,
        depth: int,
        embedding_dim: int,
        num_heads: int,
        mlp_dim: int,
        activation: Type[nn.Module] = nn.ReLU,
        attention_downsample_rate: int = 2,
    ) -> None:
        super().__init__()
        self.depth = depth
        self.embedding_dim = embedding_dim
        self.num_heads = num_heads
        self.mlp_dim = mlp_dim
        self.layers = nn.ModuleList()

        for i in range(depth):
            self.layers.append(
                TwoWayAttentionBlock2(
                    embedding_dim=embedding_dim,
                    num_heads=num_heads,
                    mlp_dim=mlp_dim,
                    activation=activation,
                    attention_downsample_rate=attention_downsample_rate,
                    skip_first_layer_pe=(i == 0),
                )
            )

        self.final_attn_token_to_image = Attention(
            embedding_dim, num_heads, downsample_rate=attention_downsample_rate
        )
        self.norm_final_attn = nn.LayerNorm(embedding_dim)

    def forward(
        self,
        image_embedding: Tensor,
        image_pe: Tensor,
        point_embedding: Tensor,
        mask_feat: Tensor = None,
    ) -> Tuple[Tensor, Tensor]:
        bs, c, h, w = image_embedding.shape
        image_embedding = image_embedding.flatten(2).permute(0, 2, 1)
        image_pe = image_pe.flatten(2).permute(0, 2, 1)

        queries = point_embedding
        keys = image_embedding

        for layer in self.layers:
            queries, keys = layer(
                queries=queries,
                keys=keys,
                query_pe=point_embedding,
                key_pe=image_pe,
                mask_feat=mask_feat,
            )

        q = queries + point_embedding
        k = keys + image_pe
        attn_out = self.final_attn_token_to_image(q=q, k=k, v=keys)
        queries = queries + attn_out
        queries = self.norm_final_attn(queries)

        return queries, keys, attn_out


class MaskDecoder2(nn.Module):
    """H-SAM second-stage mask decoder: CMAttn image-embedding enhancement,
    LMCA transformer decoder, and the hierarchical pixel decoder with skip
    connections from the stage-1 pixel decoder up to full resolution."""

    def __init__(
        self,
        *,
        transformer_dim: int,
        transformer2: nn.Module,
        num_multimask_outputs: int = 3,
        activation: Type[nn.Module] = nn.GELU,
        stage1_num_tokens: int = 3,
        cmattn_embed_dim: int = 1024,
        mask_attn_mode: str = 'learnable',
    ) -> None:
        super().__init__()
        self.transformer_dim = transformer_dim
        self.transformer2 = transformer2
        
        # 👇 核心修复：把传入的模式保存为类的属性
        self.mask_attn_mode = mask_attn_mode 

        self.num_multimask_outputs = num_multimask_outputs
        self.num_mask_tokens = num_multimask_outputs  # one token per class
        self.mask_tokens = nn.Embedding(self.num_mask_tokens, transformer_dim)

        self.output_upscaling = nn.Sequential(
            nn.ConvTranspose2d(transformer_dim, transformer_dim // 4, kernel_size=2, stride=2),
            LayerNorm2d(transformer_dim // 4),
            activation(),
            nn.ConvTranspose2d(transformer_dim // 4, transformer_dim // 8, kernel_size=2, stride=2),
            activation(),
        )
        # hierarchical pixel decoder: consumes the concatenated stage-2 and
        # stage-1 (skip) pixel-decoder features and outputs full-resolution features
        self.skip_connect = nn.Sequential(
            nn.ConvTranspose2d(transformer_dim // 4, transformer_dim // 8, kernel_size=2, stride=2),
            LayerNorm2d(transformer_dim // 8),
            activation(),
            nn.ConvTranspose2d(transformer_dim // 8, transformer_dim // 16, kernel_size=2, stride=2),
            LayerNorm2d(transformer_dim // 16),
            activation(),
        )
        self.output_hypernetworks_mlps2 = nn.ModuleList(
            [
                MLP(transformer_dim, transformer_dim, transformer_dim // 16, 5)
                for i in range(self.num_mask_tokens)
            ]
        )
        self.cm_attn = CMAttn(stage1_num_tokens=stage1_num_tokens, embed_dim=cmattn_embed_dim)
        self.softmax = nn.Softmax(dim=1)

    def forward(
        self,
        image_embeddings: torch.Tensor,
        image_pe: torch.Tensor,
        sparse_prompt_embeddings: torch.Tensor,
        dense_prompt_embeddings: torch.Tensor,
        mask_feat: torch.Tensor,
        msk_feat: torch.Tensor,
        up_embed: torch.Tensor,
        gt: torch.Tensor = None,
        mode: str = 'test',
    ) -> torch.Tensor:
        """
        Args:
          mask_feat: [B, C, h/4, w/4] stage-1 mask logits downsampled to the
            embedding resolution, used as the LMCA prior mask.
          msk_feat: [B, T, h*w/16] stage-1 mask-token logits over embeddings,
            used by CMAttn.
          up_embed: [B, transformer_dim//8, h/4, w/4] stage-1 pixel-decoder
            features (hierarchical skip connection).
        """
        
        # ================= 修复补丁：动态缩放位置编码 =================
        target_size = image_embeddings.shape[-2:]
        
        # 1. 缩放 dense_prompt_embeddings
        if dense_prompt_embeddings.shape[-2:] != target_size:
            dense_prompt_embeddings = F.interpolate(
                dense_prompt_embeddings, 
                size=target_size, 
                mode="bicubic", 
                align_corners=False
            )
            
        # 2. 缩放 image_pe
        if image_pe.shape[-2:] != target_size:
            image_pe = F.interpolate(
                image_pe, 
                size=target_size, 
                mode="bicubic", 
                align_corners=False
            )
        # ==============================================================

        output_tokens = self.mask_tokens.weight
        output_tokens = output_tokens.unsqueeze(0).expand(sparse_prompt_embeddings.size(0), -1, -1)
        tokens = torch.cat((output_tokens, sparse_prompt_embeddings), dim=1)

        # 现在维度完美匹配，不会再报错了
        src = image_embeddings + dense_prompt_embeddings
        pos_src = torch.repeat_interleave(image_pe, tokens.shape[0], dim=0)
        b, c, h, w = src.shape

        # prior probabilistic mask for LMCA
        if len(mask_feat.shape) == 3:
            mask_feat = mask_feat.unsqueeze(0)
        mask_feat = self.softmax(mask_feat).flatten(start_dim=2)

        # CMAttn image embedding enhancement
        # ================= 消融逻辑 =================
        if self.mask_attn_mode == 'none':
            # 无掩膜注意力：直接跳过 LMCAM，什么也不加
            pass 
        else:
            gate = self.cm_attn(msk_feat, h, w, gt=gt, mode=mode)
            if self.mask_attn_mode == 'binary':
                # 原始二值掩膜注意力：把概率门控变成硬 0/1
                gate = (gate > 0.5).float()
            # learnable 模式就保持原样
            src = src + torch.mul(src, gate)
        # ============================================

        hs, src, _ = self.transformer2(src, pos_src, tokens, mask_feat)
        mask_tokens_out = hs[:, 0: self.num_mask_tokens, :]

        # hierarchical pixel decoder
        src = src.transpose(1, 2).view(b, c, h, w)
        if self.training and torch.is_grad_enabled():
            upscaled_embedding = torch.utils.checkpoint.checkpoint(
                self.output_upscaling, src, use_reentrant=False)
            upscaled_embedding = torch.utils.checkpoint.checkpoint(
                self.skip_connect, torch.cat((upscaled_embedding, up_embed), dim=1), use_reentrant=False)
        else:
            upscaled_embedding = self.output_upscaling(src)
            upscaled_embedding = self.skip_connect(torch.cat((upscaled_embedding, up_embed), dim=1))

        hyper_in_list: List[torch.Tensor] = []
        for i in range(self.num_mask_tokens):
            hyper_in_list.append(self.output_hypernetworks_mlps2[i](mask_tokens_out[:, i, :]))
        hyper_in = torch.stack(hyper_in_list, dim=1)

        b, c, h, w = upscaled_embedding.shape
        masks = (hyper_in @ upscaled_embedding.view(b, c, h * w)).view(b, -1, h, w)

        return masks