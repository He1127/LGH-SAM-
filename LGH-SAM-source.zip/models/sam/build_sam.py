# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
from functools import partial
from pathlib import Path
import urllib.request
import torch
import torch.nn.functional as F

from .modeling import (
    ImageEncoderViT,
    MaskDecoder,
    PromptEncoder,
    Sam,
    TwoWayTransformer,
    TinyViT,
)


def _build_mask_decoder2(args, prompt_embed_dim, num_classes):
    """H-SAM second-stage decoder (CMAttn + LMCA + hierarchical pixel decoder)."""
    from .modeling.mask_decoder import MaskDecoder2, TwoWayTransformer2
    
    # 读取消融参数，默认是 learnable
    mask_attn_mode = getattr(args, 'mask_attn_mode', 'learnable')
    
    return MaskDecoder2(
        num_multimask_outputs=num_classes,
        transformer2=TwoWayTransformer2(
            depth=2,
            embedding_dim=prompt_embed_dim,
            mlp_dim=2048,
            num_heads=8,
        ),
        transformer_dim=prompt_embed_dim,
        stage1_num_tokens=num_classes + 1,
        cmattn_embed_dim=1024,
        mask_attn_mode=mask_attn_mode  # 传给 MaskDecoder2
    )


def build_sam_vit_h(args = None, checkpoint=None, num_classes = 1):
    return _build_sam(
        args,
        encoder_embed_dim=1280,
        encoder_depth=32,
        encoder_num_heads=16,
        encoder_global_attn_indexes=[7, 15, 23, 31],
        num_classes = num_classes,
        checkpoint=checkpoint,
    )

build_sam = build_sam_vit_h

def build_sam_vit_l(args, checkpoint=None, num_classes = 1):
    return _build_sam(
        args,
        encoder_embed_dim=1024,
        encoder_depth=24,
        encoder_num_heads=16,
        encoder_global_attn_indexes=[5, 11, 17, 23],
        num_classes = num_classes,
        checkpoint=checkpoint,
    )

def build_sam_vit_b(args, checkpoint=None, num_classes = 1):
    return _build_sam(
        args,
        encoder_embed_dim=768,
        encoder_depth=12,
        encoder_num_heads=12,
        encoder_global_attn_indexes=[2, 5, 8, 11],
        num_classes = num_classes,
        checkpoint=checkpoint,
    )

def build_sam_vit_t(args, checkpoint=None,  num_classes = 1):
    # 保持原有逻辑不变
    prompt_embed_dim = 256
    vit_patch_size = 16
    image_embedding_size = 1024 // vit_patch_size
    mobile_sam = Sam(
            args, 
            image_encoder=TinyViT(args,img_size=args.image_size, in_chans=3, num_classes=1000,
                embed_dims=[64, 128, 160, 320],
                depths=[2, 2, 6, 2],
                num_heads=[2, 4, 5, 10],
                window_sizes=[7, 7, 14, 7],
                mlp_ratio=4.,
                drop_rate=0.,
                drop_path_rate=0.0,
                use_checkpoint=False,
                mbconv_expand_ratio=4.0,
                local_conv_size=3,
                layer_lr_decay=0.8
            ),
            prompt_encoder=PromptEncoder(
            embed_dim=prompt_embed_dim,
            image_embedding_size=(image_embedding_size, image_embedding_size),
            input_image_size=(args.image_size, args.image_size),
            mask_in_chans=16,
            ),
            mask_decoder=MaskDecoder(
                    num_multimask_outputs=num_classes,
                    transformer=TwoWayTransformer(
                    args = args,
                    depth=2,
                    embedding_dim=prompt_embed_dim,
                    mlp_dim=2048,
                    num_heads=8,
                ),
                transformer_dim=prompt_embed_dim,
                iou_head_depth=3,
                iou_head_hidden_dim=256,
            ),
            pixel_mean=[123.675, 116.28, 103.53],
            pixel_std=[58.395, 57.12, 57.375],
        )

    mobile_sam.eval()
    if checkpoint is not None:
        with open(checkpoint, "rb") as f:
            state_dict = torch.load(f, map_location='cuda:0')
        try:
            mobile_sam.load_state_dict(state_dict, strict = False)
        except:
            new_state_dict = load_from_mobile(mobile_sam, state_dict)
            mobile_sam.load_state_dict(new_state_dict)
    return mobile_sam


sam_model_registry = {
    "default": build_sam_vit_h,
    "vit_h": build_sam_vit_h,
    "vit_l": build_sam_vit_l,
    "vit_b": build_sam_vit_b,
    "vit_t": build_sam_vit_t,
}


def _build_sam(
    args,
    encoder_embed_dim,
    encoder_depth,
    encoder_num_heads,
    encoder_global_attn_indexes,
    num_classes = 1,
    checkpoint=None,
):
    dev = args.devices
    prompt_embed_dim = 256
    image_size = 1024
    vit_patch_size = 16
    image_embedding_size = image_size // vit_patch_size
    
    # 【新增】根据消融参数决定是否构建 CNN 分支
    if getattr(args, 'abl_no_cba', False):
        print("⚠️ [Ablation] 正在构建模型：去除了 CBA (并行 CNN 分支)")
    
    sam = Sam(
        args,
        image_encoder=ImageEncoderViT(
            args = args,
            depth=encoder_depth,
            embed_dim=encoder_embed_dim,
            img_size=image_size,
            mlp_ratio=4,
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            num_heads=encoder_num_heads,
            patch_size=vit_patch_size,
            qkv_bias=True,
            use_rel_pos=True,
            global_attn_indexes=encoder_global_attn_indexes,
            window_size=14,
            out_chans=prompt_embed_dim,
        ),
        prompt_encoder=PromptEncoder(
            embed_dim=prompt_embed_dim,
            image_embedding_size=(image_embedding_size, image_embedding_size),
            input_image_size=(image_size, image_size),
            mask_in_chans=16,
        ),
        mask_decoder=MaskDecoder(
            num_multimask_outputs = num_classes,
            transformer=TwoWayTransformer(
                args = args,
                depth=2,
                embedding_dim=prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
        ),
        mask_decoder2=_build_mask_decoder2(args, prompt_embed_dim, num_classes),
        pixel_mean=[123.675, 116.28, 103.53],
        pixel_std=[58.395, 57.12, 57.375],
    )
    sam.eval()
        
    checkpoint = Path(checkpoint)
    # 自动下载逻辑略（保持你原来的不变）
    if not checkpoint.exists() and checkpoint.name in ["sam_vit_b_01ec64.pth", "sam_vit_h_4b8939.pth", "sam_vit_l_0b3195.pth"]:
        cmd = input(f"Download {checkpoint.name} from facebook AI? [y]/n: ")
        if len(cmd) == 0 or cmd.lower() == 'y':
            checkpoint.parent.mkdir(parents=True, exist_ok=True)
            print(f"Downloading {checkpoint.name}...")
            url_dict = {
                "sam_vit_b_01ec64.pth": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth",
                "sam_vit_h_4b8939.pth": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_h_4b8939.pth",
                "sam_vit_l_0b3195.pth": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_l_0b3195.pth"
            }
            urllib.request.urlretrieve(url_dict[checkpoint.name], checkpoint)
            print(checkpoint.name, " is downloaded!")

    if checkpoint is not None:
        with open(checkpoint, "rb") as f:
            state_dict = torch.load(f,map_location='cuda:0')
        try:
            sam.load_state_dict(state_dict, strict = False)
        except:
            new_state_dict = load_from(sam, state_dict, image_size, vit_patch_size)
            sam.load_state_dict(new_state_dict)
    
    if getattr(args, 'if_split_encoder_gpus', False):
        sam.prompt_encoder = sam.prompt_encoder.to(dev[1])
        sam.mask_decoder = sam.mask_decoder.to(dev[1])
    return sam


def load_from(sam, state_dict, image_size, vit_patch_size):
    # 保持你原来的 load_from 代码不变
    sam_dict = sam.state_dict()
    except_keys = ['mask_tokens', 'output_hypernetworks_mlps', 'iou_prediction_head']
    new_state_dict = {k: v for k, v in state_dict.items() if
                      k in sam_dict.keys() and except_keys[0] not in k and except_keys[1] not in k and except_keys[2] not in k}
    pos_embed = new_state_dict['image_encoder.pos_embed']
    token_size = int(image_size // vit_patch_size)
    if pos_embed.shape[1] != token_size:
        pos_embed = pos_embed.permute(0, 3, 1, 2)
        pos_embed = F.interpolate(pos_embed, (token_size, token_size), mode='bilinear', align_corners=False)
        pos_embed = pos_embed.permute(0, 2, 3, 1)
        new_state_dict['image_encoder.pos_embed'] = pos_embed
        rel_pos_keys = [k for k in sam_dict.keys() if 'rel_pos' in k]
        global_rel_pos_keys = [rel_pos_keys[i] for i in range(len(rel_pos_keys)) if i in [2, 5, 8, 11]]
        for k in global_rel_pos_keys:
            rel_pos_params = new_state_dict[k]
            h, w = rel_pos_params.shape
            rel_pos_params = rel_pos_params.unsqueeze(0).unsqueeze(0)
            rel_pos_params = F.interpolate(rel_pos_params, (token_size * 2 - 1, w), mode='bilinear', align_corners=False)
            new_state_dict[k] = rel_pos_params[0, 0, ...]
    sam_dict.update(new_state_dict)
    return sam_dict

def load_from_mobile(sam, state_dict):
    # 保持你原来的不变
    sam_dict = sam.state_dict()
    except_keys = ['mask_tokens', 'output_hypernetworks_mlps', 'iou_prediction_head']
    new_state_dict = {k: v for k, v in state_dict.items() if
                      k in sam_dict.keys() and except_keys[0] not in k and except_keys[1] not in k and except_keys[2] not in k}
    sam_dict.update(new_state_dict)
    return sam_dict