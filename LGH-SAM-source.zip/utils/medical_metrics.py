"""Medical image segmentation metrics following the MedAdapt-SAM paper (Table 5, CHASEDB1):
ACC, F1 (= Dice), mIoU and HD95.

Conventions (verified against the paper's reported numbers):
- ACC  = (TP+TN)/(TP+TN+FP+FN), foreground vs background, computed per image.
- F1   = 2TP/(2TP+FP+FN)  (Eq.6 in the paper; identical formula to Dice/DSC).
- mIoU = foreground-class IoU = TP/(TP+FP+FN) per image (the paper's Table 5 mIoU
         matches the foreground IoU, e.g. ATUKAN Dice 81.34 -> IoU 68.59 = mIoU 68.59).
- HD95 = 95th-percentile Hausdorff distance between the prediction and ground-truth
         surfaces, taking the max of the two directed distances (in pixels).

All functions take binary masks as numpy arrays of identical shape.
"""
import numpy as np
from scipy.ndimage import distance_transform_edt, binary_erosion


def seg_confusion(pred, gt):
    """Return TP, FP, FN, TN for a binary prediction / ground-truth pair."""
    pred = pred.astype(bool)
    gt = gt.astype(bool)
    tp = np.logical_and(pred, gt).sum()
    fp = np.logical_and(pred, ~gt).sum()
    fn = np.logical_and(~pred, gt).sum()
    tn = np.logical_and(~pred, ~gt).sum()
    return tp, fp, fn, tn


def accuracy_score(pred, gt, eps=1e-7):
    """Pixel accuracy (TP+TN)/(TP+TN+FP+FN)."""
    tp, fp, fn, tn = seg_confusion(pred, gt)
    return (tp + tn) / (tp + tn + fp + fn + eps)


def dice_f1_score(pred, gt, eps=1e-7):
    """F1 score, identical formula to Dice/DSC: 2TP/(2TP+FP+FN)."""
    tp, fp, fn, _ = seg_confusion(pred, gt)
    return 2.0 * tp / (2.0 * tp + fp + fn + eps)


def iou_score(pred, gt, eps=1e-7):
    """Foreground (class-1) IoU: TP/(TP+FP+FN). Reported as mIoU in Table 5."""
    tp, fp, fn, _ = seg_confusion(pred, gt)
    return tp / (tp + fp + fn + eps)


def _surface(mask):
    """Foreground boundary pixels of a binary mask."""
    return mask & ~binary_erosion(mask)


def hausdorff_distance_95(pred, gt, percentile=95):
    """95th-percentile Hausdorff distance (HD95) between two binary masks, in pixels.

    Follows MedPy's hd95: surfaces are extracted with binary erosion, distances are
    computed with the euclidean distance transform in both directions and pooled,
    and HD95 is the percentile of the pooled surface distances:
        HD95 = P95( [dist(surf(pred)->surf(gt)), dist(surf(gt)->surf(pred))] )
    If one mask is empty and the other is not, the image diagonal is returned as
    penalty; if both are empty the distance is 0.
    """
    pred = pred.astype(bool)
    gt = gt.astype(bool)
    if not pred.any() and not gt.any():
        return 0.0
    if not pred.any() or not gt.any():
        # penalize with the image diagonal when one of the masks is empty
        return float(np.hypot(*pred.shape))

    pred_surf = _surface(pred)
    gt_surf = _surface(gt)

    # distance from every pixel to the nearest surface pixel of the other mask
    d_pred_to_gt = distance_transform_edt(~gt_surf)[pred_surf]
    d_gt_to_pred = distance_transform_edt(~pred_surf)[gt_surf]

    return float(np.percentile(np.hstack((d_pred_to_gt, d_gt_to_pred)), percentile))


def all_metrics(pred, gt):
    """Compute all four Table-5 metrics for one binary mask pair."""
    return {
        'acc': accuracy_score(pred, gt),
        'f1': dice_f1_score(pred, gt),
        'miou': iou_score(pred, gt),
        'hd95': hausdorff_distance_95(pred, gt),
    }
