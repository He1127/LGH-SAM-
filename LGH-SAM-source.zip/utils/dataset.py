import os, torch
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
import cv2
import random
# Optional 3D-volume dependencies; only needed for NIfTI/nrrd pipelines, not for 2D png datasets
try:
    import torchio as tio
    import slicerio
    import nrrd
    import nibabel as nib
except ImportError:
    tio = slicerio = nrrd = nib = None
import monai
import pickle
from scipy.ndimage import zoom, gaussian_filter
import einops
from utils.funcs import *
from torchvision.transforms import InterpolationMode

class Public_dataset(Dataset):
    def __init__(self,args, img_folder, mask_folder, img_list,phase='train',sample_num=50,channel_num=1,normalize_type='sam',crop=False,crop_size=1024,targets=['femur','hip'],part_list=['all'],cls=-1,if_prompt=True,prompt_type='point',region_type='largest_3',label_mapping=None,if_spatial=True,delete_empty_masks=True):
        super(Public_dataset, self).__init__()
        self.args = args
        self.img_folder = img_folder
        self.mask_folder = mask_folder
        self.crop = crop
        self.crop_size = crop_size
        self.phase = phase
        self.normalize_type = normalize_type
        self.targets = targets
        self.part_list = part_list
        self.cls = cls
        self.delete_empty_masks = delete_empty_masks
        self.if_prompt = if_prompt
        self.prompt_type = prompt_type
        self.region_type = region_type
        self.label_dic = {}
        self.data_list = []
        self.label_mapping = label_mapping
        self.load_label_mapping()
        self.load_data_list(img_list)
        self.if_spatial = if_spatial
        self.setup_transformations()

    def load_label_mapping(self):
        if self.label_mapping:
            with open(self.label_mapping, 'rb') as handle:
                self.segment_names_to_labels = pickle.load(handle)
            self.label_dic = {seg[1]: seg[0] for seg in self.segment_names_to_labels}
            self.label_name_list = [seg[0] for seg in self.segment_names_to_labels]
            print(self.label_dic)
        else:
            self.segment_names_to_labels = {}
            self.label_dic = {value: 'all' for value in range(1, 256)}

    def load_data_list(self, img_list):
        with open(img_list, 'r') as file:
            lines = file.read().strip().split('\n')
            
        if len(lines) > 0 and 'image' in lines[0] and 'mask' in lines[0]:
            lines = lines[1:]
            
        for line in lines:
            if not line.strip(): continue 
            
            img_path, mask_path = line.split(',')
            mask_path = mask_path.strip()
            if mask_path.startswith('/'):
                mask_path = mask_path[1:]
                
            try:
                full_mask_path = os.path.join(self.mask_folder, mask_path)
                msk = Image.open(full_mask_path).convert('L')
                if self.should_keep(msk, mask_path):
                    self.data_list.append(line)
            except Exception as e:
                print(f"⚠️ 警告: 找不到掩码文件 {full_mask_path}，已跳过。")

        print(f'Filtered data list to {len(self.data_list)} entries.')

    def should_keep(self, msk, mask_path):
        if self.delete_empty_masks:
            mask_array = np.array(msk, dtype=int)
            if 'combine_all' in self.targets:
                return np.any(mask_array > 0)
            elif 'multi_all' in self.targets:
                return np.any(mask_array > 0)
            elif any(target in self.targets for target in self.segment_names_to_labels):
                target_classes = [self.segment_names_to_labels[target][1] for target in self.targets if target in self.segment_names_to_labels]
                return any(mask_array == cls for cls in target_classes)
            elif self.cls>0:
                return np.any(mask_array == self.cls)
            if self.part_list[0] != 'all':
                return any(part in mask_path for part in self.part_list)
            return False
        else:
            return True

    def setup_transformations(self):
        transformations = [transforms.ToTensor()]
        if self.normalize_type == 'sam':
            transformations.append(transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]))
        elif self.normalize_type == 'medsam':
            transformations.append(transforms.Lambda(lambda x: (x - torch.min(x)) / (torch.max(x) - torch.min(x))))
        self.transform_img = transforms.Compose(transformations)

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, index):
        data = self.data_list[index]
        img_path, mask_path = data.split(',')
        if mask_path.startswith('/'):
            mask_path = mask_path[1:]
        img = Image.open(os.path.join(self.img_folder, img_path.strip())).convert('RGB')
        msk = Image.open(os.path.join(self.mask_folder, mask_path.strip())).convert('L')

        img = transforms.Resize((self.args.image_size,self.args.image_size))(img)
        msk = transforms.Resize((self.args.image_size,self.args.image_size),InterpolationMode.NEAREST)(msk)
        
        img, msk = self.apply_transformations(img, msk)

        # 标签处理
        if 'combine_all' in self.targets: 
            msk = np.array(np.array(msk,dtype=int)>0,dtype=int)
        elif 'multi_all' in self.targets:
            msk = np.array(msk,dtype=int)
        elif self.cls>0:
            msk = np.array(msk==self.cls,dtype=int)
            
        return self.prepare_output(img, msk, img_path, mask_path)

    def apply_transformations(self, img, msk):
        if self.crop:
            img, msk = self.apply_crop(img, msk)
        if self.phase == 'train' and self.if_spatial:
            img, msk = self.apply_augmentations(img, msk)
        img = self.transform_img(img)
        msk = torch.tensor(np.array(msk, dtype=int), dtype=torch.long)
        return img, msk

    def apply_augmentations(self, img, msk):
        img = np.array(img)  
        msk = np.array(msk)  

        # 1. 原有的随机翻转
        if random.random() < 0.5:
            img, msk = np.flip(img, 1), np.flip(msk, 1)
        if random.random() < 0.5:
            img, msk = np.flip(img, 0), np.flip(msk, 0)
        
        # 2. 新增：随机缩放 (0.85 ~ 1.15 倍)
        if random.random() < 0.4:
            scale = random.uniform(0.85, 1.15)
            h, w = msk.shape[:2]
            new_h, new_w = int(h * scale), int(w * scale)
            
            img_scaled = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            msk_scaled = cv2.resize(msk, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            
            if scale >= 1.0:
                start_h = (new_h - h) // 2
                start_w = (new_w - w) // 2
                img = img_scaled[start_h:start_h+h, start_w:start_w+w]
                msk = msk_scaled[start_h:start_h+h, start_w:start_w+w]
            else:
                pad_h = (h - new_h) // 2
                pad_w = (w - new_w) // 2
                img = np.pad(img_scaled, ((pad_h, h-new_h-pad_h), (pad_w, w-new_w-pad_w), (0,0)), mode='constant')
                msk = np.pad(msk_scaled, ((pad_h, h-new_h-pad_h), (pad_w, w-new_w-pad_w)), mode='constant')

        img, msk = np.ascontiguousarray(img), np.ascontiguousarray(msk)

        # 3. 原有的随机旋转
        if random.random() < 0.5:
            ang = random.uniform(-45, 45)
            h, w = msk.shape[:2]
            M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0)
            img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
            msk = cv2.warpAffine(msk, M, (w, h), flags=cv2.INTER_NEAREST, borderValue=0)

        # 4. 原有的弹性形变
        if random.random() < 0.3:
            img, msk = self.elastic_transform(img, msk, alpha=15, sigma=5)

        # 5. 🔥 新增：随机裁剪 (概率 0.5，裁剪出 75% 的区域，然后再 resize 回原大小)
        # 这一招是防止 Synapse 多分类过拟合的杀手锏
        if random.random() < 0.5:
            h, w = msk.shape[:2]
            crop_size_h = int(h * random.uniform(0.7, 0.85))
            crop_size_w = int(w * random.uniform(0.7, 0.85))
            
            top = random.randint(0, h - crop_size_h)
            left = random.randint(0, w - crop_size_w)
            
            img = img[top:top+crop_size_h, left:left+crop_size_w]
            msk = msk[top:top+crop_size_h, left:left+crop_size_w]
            
            img = cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR)
            msk = cv2.resize(msk, (w, h), interpolation=cv2.INTER_NEAREST)

        # 6. 像素级增强（保持原样）
        if random.random() < 0.5:
            img = np.clip(img.astype(np.float32) * random.uniform(0.8, 1.2) + random.uniform(-25, 25), 0, 255).astype(np.uint8)
        if random.random() < 0.3:
            g = random.uniform(0.7, 1.5)
            img = np.clip((img / 255.0) ** g * 255.0, 0, 255).astype(np.uint8)
        if random.random() < 0.25:
            img = np.clip(img.astype(np.float32) + np.random.normal(0, 7, img.shape), 0, 255).astype(np.uint8)
        if random.random() < 0.25:
            k = random.choice([3, 5])
            img = cv2.GaussianBlur(img, (k, k), random.uniform(0.5, 1.5))

        return Image.fromarray(img), Image.fromarray(msk)

    def elastic_transform(self, img, msk, alpha=15, sigma=5):
        h, w = msk.shape[:2]
        dx = gaussian_filter((np.random.rand(h, w) * 2 - 1), sigma) * alpha
        dy = gaussian_filter((np.random.rand(h, w) * 2 - 1), sigma) * alpha
        x, y = np.meshgrid(np.arange(w), np.arange(h))
        map_x = (x + dx).astype(np.float32)
        map_y = (y + dy).astype(np.float32)
        img = cv2.remap(img, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        msk = cv2.remap(msk, map_x, map_y, interpolation=cv2.INTER_NEAREST, borderMode=cv2.BORDER_REFLECT)
        return img, msk

    def apply_crop(self, img, msk):
        t, l, h, w = transforms.RandomCrop.get_params(img, (self.crop_size, self.crop_size))
        img = transforms.functional.crop(img, t, l, h, w)
        msk = transforms.functional.crop(msk, t, l, h, w)
        return img, msk

    def prepare_output(self, img, msk, img_path, mask_path):
        if len(msk.shape)==2:
            msk = torch.unsqueeze(torch.tensor(msk,dtype=torch.long),0)
        output = {'image': img, 'mask': msk, 'img_name': img_path, 'mask_name': mask_path}
        if self.if_prompt:
            if self.prompt_type == 'point':
                prompt, mask_now = get_first_prompt(msk.numpy()[0], region_type=self.region_type)
                pc = torch.tensor(prompt[:, :2], dtype=torch.float)
                pl = torch.tensor(prompt[:, -1], dtype=torch.float)
                msk = torch.unsqueeze(torch.tensor(mask_now,dtype=torch.long),0)
                output.update({'point_coords': pc, 'point_labels': pl,'mask':msk})
            elif self.prompt_type == 'box':
                prompt, mask_now = get_top_boxes(msk.numpy()[0], region_type=self.region_type)
                box = torch.tensor(prompt, dtype=torch.float)
                msk = torch.unsqueeze(torch.tensor(mask_now,dtype=torch.long),0)
                output.update({'boxes': box,'mask':msk})
            elif self.prompt_type == 'hybrid':
                point_prompt, _ = get_first_prompt(msk[0].numpy(), self.region_type)
                box_prompt, _ = get_top_boxes(msk.numpy(), this.region_type)
                pc = torch.tensor(point_prompt[:, :2], dtype=torch.float)
                pl = torch.tensor(point_prompt[:, -1], dtype=torch.float)
                box = torch.tensor(box_prompt, dtype=torch.float)
                output.update({'point_coords': pc, 'point_labels': pl, 'boxes': box})
        return output